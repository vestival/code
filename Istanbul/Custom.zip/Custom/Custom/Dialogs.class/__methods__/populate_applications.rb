#
# Description:
#

# gop, icsi, gmds
application_list = {
  :gop => 'gop',
  :icsi =>'icsi',
  :gmds =>'gmds'
}

application_list[nil] = application_list.empty? ? "<None>" : "<Not required>"

$evm.log(:info, "application_list: #{application_list}")

dialog_field = $evm.object

# sort_by: value / description / none
dialog_field["sort_by"] = "description"

# sort_order: ascending / descending
dialog_field["sort_order"] = "ascending"

# data_type: string / integer
dialog_field["data_type"] = "string"

# required: true / false
dialog_field["required"] = "false"

dialog_field["values"] = application_list
dialog_field["default_value"] = nil
