#
# Description: Determine current 'environments' i.e last two
#              numbers of VM name and add one, for the next available
#
environment = {}
active_environments = []

# vms = $evm.vmdb('vm').find(:all, :conditions => ["active = ?",  true])
vmdb_vms = $evm.vmdb('vm').all

#vmdb_vms = ['c1gmds01', 'c2gop02', 'c3icsi03']
vmdb_vms.each do |vm|
  if vm.active and match = vm.name.match(/^c\d{1}(gop|icsi|gmds)(\d{2})$/i)
  # if match = vm.match(/^c\d{1}(gop|icsi|gmds)(\d{2})$/i)
    $evm.log(:info, "Match: #{vm}")
    active_environments << match[2]
  end
end
$evm.log(:info, "active_environments.count: #{active_environments.count}")
$evm.log(:info, "active_environments: #{active_environments}")

if active_environments.empty?
  environment['01'] = '01'
else
  active_environments = active_environments.sort.uniq
  # active_environments.each { |e| environment[e] = e }
  next_environment = (active_environments[-1]).succ
  environment[next_environment] = next_environment
end
$evm.log(:info, "environment: #{environment}")

# environment[nil] = environment.empty? ? "01" : "01"

dialog_field = $evm.object

# sort_by: value / description / none
dialog_field["sort_by"] = "description"

# sort_order: ascending / descending
dialog_field["sort_order"] = "ascending"

# data_type: string / integer
dialog_field["data_type"] = "string"

# required: true / false
dialog_field["required"] = "true"

dialog_field["values"] = environment
dialog_field["default_value"] = nil
