#
# Description: Service Approval Request Validation
#
# validate_request.rb
# 
# validate_request  Copyright (C) 2016 Christian Jung
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# 
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

def log(level, msg, update_message=false)
  $evm.log(level, "#{msg}")
end

def dump_root()
  $evm.log(:info, "Begin $evm.root.attributes")
  $evm.root.attributes.sort.each { |k, v| log(:info, "\t Attribute: #{k} = #{v}")}
  $evm.log(:info, "End $evm.root.attributes")
  $evm.log(:info, "")
end

# get_options_hash - Look for service dialog variables in the dialog options hash that start with "dialog_option_[0-9]"
def get_options_hash(dialog_options)
  # Setup regular expression for service dialog tags
  options_regex = /^dialog_option_(\d*)_(.*)/i
  options_hash = {}
  # Loop through all of the options and build an options_hash from them
  dialog_options.each do |k,v|
    next if v.blank?
    if options_regex =~ k
      sequence_id = $1.to_i
      option_key = $2.to_s.downcase.to_sym
      log(:info, "Adding via regex sequence_id: #{sequence_id} option_key: #{option_key.inspect} option_value: #{v.inspect} to options_hash")
      if options_hash.has_key?(sequence_id)
        options_hash[sequence_id][option_key] = v
      else
        options_hash[sequence_id] = { option_key => v }
      end
    else
      # If options_regex does not match then stuff dialog options into options_hash[0]
      sequence_id = 0
      option_key = k.downcase.to_sym
      log(:info, "Adding sequence_id: #{sequence_id} option_key: #{option_key.inspect} v: #{v.inspect} to options_hash")
      if options_hash.has_key?(sequence_id)
        options_hash[sequence_id][option_key] = v
      else
        options_hash[sequence_id] = { option_key => v }
      end
    end # if options_regex =~ k
  end # dialog_options.each do
  log(:info, "Inspecting options_hash: #{options_hash.inspect}")
  return options_hash
end

###############
# Start Method
###############
log(:info, "CloudForms Automate Method Started", true)
dump_root()

# get the request object from root
@miq_request = $evm.root['miq_request']
log(:info, "miq_request.id: #{@miq_request.id} miq_request.options[:dialog]: #{@miq_request.options[:dialog].inspect}")

#####################################################################
# Flavour support, dialogue must include option_N_flavor
# Otherwise, flavour of the selected template used.
#####################################################################

# Get dialog options from miq_request (to check for overriding requests)
dialog_options = @miq_request.options[:dialog]
log(:info, "Inspecting Dialog Options: #{dialog_options.inspect}")
options_hash = get_options_hash(dialog_options)

# lookup the service_template object
@service_template = $evm.vmdb(@miq_request.source_type, @miq_request.source_id)
log(:info, "service_template id: #{@service_template.id} service_type: #{@service_template.service_type} description: #{@service_template.description} services: #{@service_template.service_resources.count}")

reason_hash = {}

retirement = options_hash[0][:dialog_retirement]
log(:info, "Retirement date from Dialog: #{retirement}")
if retirement == 0 then
  log(:info, "Retirement is indifinite, approval required")
  reason_hash[:reason1]="Retirement is indifinite"
end

cost = 0
cost2 = 0
size = 0
disk = 0
total = 0
disk = options_hash[0][:dialog_disksize]
size = options_hash[0][:dialog_size]
case size
 when "small"
  cost = 10
  $evm.log("info", "Size #{size}, cost #{cost}")
 when "medium"
  cost = 20
  $evm.log("info", "Size #{size}, cost #{cost}")
 when "large"
  cost = 50
  $evm.log("info", "Size #{size}, cost #{cost}")
end
  
case disk
 when 0
  cost2 = 0
  total = cost + cost2
  $evm.log("info", "Disk Size #{cost2} no extra cost")
 when 10
  cost2 = 10
  total = cost + cost2
  $evm.log("info", "Size #{size}, extra cost #{cost2}, total cost is #{total}")
 when 50
  cost2 = 50
  total = cost + cost2
  $evm.log("info", "Size #{size}, extra cost #{cost2}, total cost is #{total}")
 when 200
  cost2 = 200
  total = cost + cost2
  $evm.log("info", "Size #{size}, extra cost #{cost2}, total cost is #{total}")
end

if total > 150 then
  log(:info, "Total cost above 150, approval required")
  reason_hash[:reason2]='Total cost is above 150'
end

# if approval required then send request into a pending state
log(:info, "reason_hash: #{reason_hash.inspect}")
unless reason_hash.blank?
  msg =  "Service Request was not auto-approved for the following reason(s): "
  msg += "(#{reason_hash[:reason1]}) " unless reason_hash[:reason1].blank?
  msg += "(#{reason_hash[:reason2]}) " unless reason_hash[:reason2].blank?
  msg += "(#{reason_hash[:reason3]}) " unless reason_hash[:reason3].blank?
  @miq_request.set_message(msg)
  $evm.root['ae_result'] = 'error'
  $evm.object['reason'] = msg
end
