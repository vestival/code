###################################
#
# EVM Automate Method: fill_additional_approvers
#
# Notes: This method verify that the category for additional approvers exists
# and creates it if not. It also generate the tags automatically based on the 
# current users with 'EvmGroup-approver' role
# This method is used in 'VM Provisioning Group (VM)' automate class
#
###################################

category_name = 'prov_additional_approvers'
category_desc = 'Auto-Approve - Additional Approvers'

# Create category if not existant
if $evm.execute('category_exists?', category_name)
  $evm.log("info", "Category <#{category_name}> exists")
else
  $evm.log("info", "Category <#{category_name}> doesn't exist, creating category")
  $evm.execute('category_create', :name => category_name, :single_value => false, :description => "#{category_desc}")
end

# Create tag for all approver users if not already existing
group =  $evm.vmdb('miq_group').find_by_description('EvmGroup-approver')
$evm.log("info", "Group #{group.description} found")
return if group.nil?
group.users.each do |user|
  $evm.log("info", user.inspect)
  $evm.log("info", "User #{user.userid} (#{user.name}) is part of group #{group.description}")
  result = $evm.execute('tag_exists?', category_name, user.userid)
  if result == false
    result = $evm.execute('tag_create', category_name, :name => user.userid, :description => user.name)
    $evm.log("info", "Tag #{user.userid} created under catagory #{category_name}") if result == true
  end
end
