#
# Description: This method is used to email the requester that the Service request was not auto-approved
#

def send_mail(to, from, subject, body)
  $evm.log(:info, "Sending email to #{to} from #{from} subject: #{subject}")
  $evm.execute(:send_email, to, from, subject, body)
end

def requester
  @miq_request.requester
end

def signature
  $evm.object['signature']
end

def reason
  @miq_request.reason
end

def approver_href(appliance)
  body = "<a href='https://#{appliance}/miq_request/show/#{@miq_request.id}'"
  body += ">https://#{appliance}/miq_request/show/#{@miq_request.id}</a>"
  body
end

def approver_text(appliance, requester_email)
  body = "Approver, "
  body += "<br>A Service request received from #{requester_email} is pending."
  body += "<br><br>"
  body += "#{@options_hash}"
  body += "<br><br>"
  body += "VM Name(s): #{@vm_name_array}"
  body += "<br><br>"
  body += "VM Name(s): #{@final_vm_names}"
  body += "<br>"
  body += "<br><br>Approvers notes: #{@miq_request.reason}"
  body += "<br><br>For more information you can go to: "
  body += approver_href(appliance)
  body += "<br><br> Thank you,"
  body += "<br> #{signature}"
  $evm.log(:info, body)
  body
end

def requester_email_address
  owner_email = @miq_request.options.fetch(:owner_email, nil)
  email = requester.email || owner_email || $evm.object['to_email_address']
  $evm.log(:info, "To email: #{email}")
  email
end

def email_approver(appliance)
  $evm.log(:info, "Requester email logic starting")
  requester_email = requester_email_address
  to  = $evm.object['to_email_address']
  from = $evm.object['from_email_address']
  subject = "Request ID #{@miq_request.id} - Virtual machine request was not approved"

  send_mail(to, from, subject, approver_text(appliance, requester_email))
end

def requester_href(appliance)
  body = "<a href='https://#{appliance}/miq_request/show/#{@miq_request.id}'>"
  body += "https://#{appliance}/miq_request/show/#{@miq_request.id}</a>"
  body
end

def requester_text(appliance)
  body = "Hello, "
  body += "<br><br>Please review your Request and wait for approval from an Administrator."
  body += "<br><br>To view this Request go to: "
  body += requester_href(appliance)
  body += "<br><br> Thank you,"
  body += "<br> #{signature}"
  body
end

def email_requester(appliance)
  $evm.log(:info, "Requester email logic starting")
  to = requester_email_address
  from = $evm.object['from_email_address']
  subject = "Request ID #{@miq_request.id} - Your Service Request was not Auto-Approved"

  send_mail(to, from, subject, requester_text(appliance))
end

def log(level, msg, update_message=false)
  $evm.log(level, "#{msg}")
end

def dump_root()
  $evm.log(:info, "Begin $evm.root.attributes")
  $evm.root.attributes.sort.each { |k, v| log(:info, "\t Attribute: #{k} = #{v}")}
  $evm.log(:info, "End $evm.root.attributes")
  $evm.log(:info, "")
end

# get_options_hash - Look for service dialog variables in the dialog options hash that start with "dialog_option_[0-9]"
def get_options_hash(dialog_options)
  # Setup regular expression for service dialog tags
  options_regex = /^dialog_option_(\d*)_(.*)/i
  options_hash = {}
  # Loop through all of the options and build an options_hash from them
  dialog_options.each do |k,v|
    next if v.blank?
    if options_regex =~ k
      sequence_id = $1.to_i
      option_key = $2.to_s.downcase.to_sym
      log(:info, "Adding via regex sequence_id: #{sequence_id} option_key: #{option_key.inspect} option_value: #{v.inspect} to options_hash")
      if options_hash.has_key?(sequence_id)
        options_hash[sequence_id][option_key] = v
      else
        options_hash[sequence_id] = { option_key => v }
      end
    else
      # If options_regex does not match then stuff dialog options into options_hash[0]
      sequence_id = 0
      option_key = k.downcase.to_sym
      log(:info, "Adding sequence_id: #{sequence_id} option_key: #{option_key.inspect} v: #{v.inspect} to options_hash")
      if options_hash.has_key?(sequence_id)
        options_hash[sequence_id][option_key] = v
      else
        options_hash[sequence_id] = { option_key => v }
      end
    end # if options_regex =~ k
  end # dialog_options.each do
  log(:info, "Inspecting options_hash: #{options_hash.inspect}")
  return options_hash
end

begin
  dump_root()
  
  @miq_request = $evm.root['miq_request']
  $evm.log(:info, "miq_request id: #{@miq_request.id} approval_state: #{@miq_request.approval_state}")
  $evm.log(:info, "options: #{@miq_request.options.inspect}")

  service_template = $evm.vmdb(@miq_request.source_type, @miq_request.source_id)
  $evm.log(:info, "service_template id: #{service_template.id} service_type: #{service_template.service_type}")
  $evm.log(:info, "description: #{service_template.description} services: #{service_template.service_resources.count}")

  appliance = $evm.root['miq_server'].ipaddress
  
  dialog_options = @miq_request.options[:dialog] # alternatively @miq_request.get_option(:dialog)
  log(:info, "Inspecting Dialog Options: #{dialog_options}")
  @options_hash = get_options_hash(dialog_options)

  $evm.log(:info, "options_hash: #{@options_hash}")

  # @vm_name_array = []
  if @options_hash[0]
    resource_group = @options_hash[0][:dialog_resource_group]
    unless resource_group.nil?

      if resource_group == 'bistech'
        # paxxxxyy - BISTECH Resource Hostname Function (max 8 characters)
        @options_hash.each do |index, hash|
          next if index == 0
          # application_code = hash[:application_code]
          # @options_hash[index][:vm_name] = "p#{index}#{hash[:application_code]}01"
          dialog_options["dialog_option_#{index}_vm_name"] = "p#{index}#{hash[:application_code]}01"
        end

      elsif resource_group == 'non_bistech'
        # AxxxxByy - Non-BISTECH Resource Hostname Function (max 8 characters)
        location                    = @options_hash[0][:dialog_location]
        application_code            = @options_hash[0][:application_code]
        # TO DO: application_code max 4 characters
        environment                 = @options_hash[0][:dialog_environment]
        # @options_hash[0][:vm_name]  = "#{location}#{application_code}#{environment}01"
        dialog_options["dialog_option_0_vm_name"] = "#{location}#{application_code}#{environment}01"
      end
    end
  end
  # $evm.log(:info, "options_hash: #{@options_hash}")
  # $evm.log(:info, "dialog_options: #{dialog_options}")

  # vms = $evm.vmdb('vm').find(:all, :conditions => ["active = ?",  true])
  vmdb_vms = $evm.vmdb('vm').all

  # Create an array of the active VM names for efficiency
  active_vmdb_vms = []
  active_vmdb_vms = ['p1gmds01', 'p2gop01', 'p3icsi01', 'ycldd01']
  vmdb_vms.each do |vm|
    active_vmdb_vms << vm.name if vm.active
  end
  active_vmdb_vms = active_vmdb_vms.sort.uniq # just in case
  $evm.log(:info, "active_vmdb_vms.count: #{active_vmdb_vms.count}")

  @options_hash.each do |index, hash|
    $evm.log(:info, "#{index}: #{hash}")
    # next if index == 0
    vm_name = hash[:vm_name]
    next if vm_name.nil?

    $evm.log(:info, "vm_name: #{vm_name}")

    # 'p1gmds01'.match(/(.*)\d{2}$/)

    if active_vmdb_vms.include?(vm_name)
      $evm.log(:info, "Name in use")

      ## TO DO: Find CFME method which does this

      if match = vm_name.match(/(.*)\d{2}$/)
        this_vm_prefix = match[1]
        $evm.log(:info, "this_vm_prefix: #{this_vm_prefix}")
        vms_with_prefix = []
        active_vmdb_vms.each do |vm|
          vms_with_prefix << vm if vm.match(/^#{match[1]}/)
        end
      end

      raise 'vms_with_prefix is empty' if vms_with_prefix.empty?
      derived_name = (vms_with_prefix[-1]).succ
      $evm.log(:info, "New name: #{derived_name}")

      # @options_hash[index][:vm_name] = derived_name
      dialog_options["dialog_option_#{index}_vm_name"] = derived_name

    else
      $evm.log(:info, "Name available")
    end
  end

  # @miq_request.set_option(:dialog,'nick_woz_ere')
  $evm.log(:info, "updated_dialog_options: #{dialog_options}")
  @miq_request.set_option(:dialog, dialog_options)

  email_requester(appliance)
  email_approver(appliance)
rescue => err
  $evm.log(:info, "[#{err}]\n#{err.backtrace.join("\n")}")
  exit MIQ_STOP
end
