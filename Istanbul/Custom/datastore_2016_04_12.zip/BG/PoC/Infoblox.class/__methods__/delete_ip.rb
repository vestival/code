begin

  require 'rest-client'
  require 'json'
  require 'nokogiri'
  require 'openssl'
  
  # Method for logging
  def log(level, message)
    @method = '----- Delete Infoblox Registration -----'
    $evm.log(level, "#{@method} - #{message}")
  end 
  
  log(:info, "Running")
  
  @infoblox_user = 's50redhat'
  @infoblox_password = 'RedHat14'
  @infoblox_host = '10.148.208.38'
  @infoblox_uribase = "https://#{@infoblox_user}:#{@infoblox_password}@#{@infoblox_host}/wapi/v1.4.1"

  headers = {"Content-Type" => 'application/json', "Accept" => 'application/json;version=2'}


  # ----------------------------------------------------------------------------
  # Get host name from VM object
  
  vm = $evm.root['vm']
  log(:info, "vm.inspect => #{vm.inspect}")
  raise 'The VM object is empty' if vm.nil?
  $evm.log(:info, "vm.inspect => #{vm.inspect}")
    
  hostname = "#{vm.name}" + ".plus.local"
  
  # ----------------------------------------------------------------------------
  # Find all objects for an IP address

  uri = "#{@infoblox_uribase}/search?search_string=#{hostname}"
  #puts uri.inspect

  request = RestClient::Request.new(
    method: :get,
    url: uri,
    headers: headers
  )

  json=request.execute
  results=JSON.parse(json)
  #puts results.count
  
  results.each do |result|
        ref = result["_ref"]
        uri = "#{@infoblox_uribase}/#{ref}"
        #puts uri.inspect
        request = RestClient::Request.new(
                method: :delete,
                url: uri,
                headers: headers
        )
        result=request.execute
        #puts result.inspect
  end
rescue => err
        log(:error, "[#{err}]\n#{err.backtrace.join("\n")}")
        exit MIQ_ABORT
end
