#
# Description: <Method description here>
#

begin

	# Method for logging
	def log(level, message)
		@method = '----- foreman host create -----'
		$evm.log(level, "#{@method} - #{message}")
	end

	# Method for adding new host to specified host group
	def set_hostgroup(vm, slot, host_id, parameters_hash, instance_name, instance_port)

		uri_base = "https://#{@satellite_user}:#{@satellite_password}@#{@satellite_host}/api/v2"	
      	uri = "#{uri_base}/hosts/#{host_id}/parameters"
		log(:info, "uri => #{uri}") if @debug

		headers = {'Content-Type' => 'application/json', 'Accept' => 'application/json;version=2'}

		parameters_hash.each do |k, v|

			log(:info, "#{k} => #{v}") 
			request = RestClient::Request.new(
				method: :post,
				url: uri,
				headers: headers,
	          payload: {:name => k, :value => v}.to_json
			)

		 	rest_return = request.execute
		 	log(:info, "rest_return => #{rest_return.inspect}")
		end  

      tag = slot + '_' + instance_name.downcase + '_' + instance_port
	 	log(:info, "tag => #{tag}") if @debug

		unless $evm.execute('tag_exists?', @category_name, tag)
			log(:info, "#{@method} - Creating <#{@category_name}/#{tag}> tag")
			$evm.execute('tag_create', @category_name, :name => tag, :description => tag)
		end
      
    	vm.tag_assign("#{@category_name}/#{tag}")

	end

	# Start

	10.times { log(:info, 'CloudForms Automate Method Started') }
 	# 10.times { log(:info, '============================================') }
	@debug = true

	require 'rest-client'
	require 'json'
	require 'openssl'

	@satellite_user = 'admin'
	@satellite_password = 'RedHat14'
	@satellite_host = 'satellite.plus.local'
	uri_base = "https://#{@satellite_user}:#{@satellite_password}@#{@satellite_host}/api/v2"

	prov = $evm.root['miq_provision']
	log(:info, "prov.vm.inspect => #{prov.vm.inspect}")

	vm = prov.vm unless prov.nil?
	raise 'The VM object is empty' if vm.nil?

	10.times { log(:info, '============================================') }

    function = vm.tags(:function)
    log(:info, "function tags: #{function.inspect}")
    # log(:info, "function methods: #{function.methods.inspect}")

    if function.include?('application_servers')
    	@type = 'application'
    	@category_name = 'app_slots'
    else
    	@type = 'database'
    	@category_name = 'db_slots'
    end

	$evm.log("info", "Type => <#{@type}>")
	10.times { log(:info, '============================================') }

	# Grab dialogue options
	options = prov.miq_provision_request.options[:dialog]
	$evm.log("info","Dialog Options = #{options}")
	raise 'The dialogue object is empty' if options.nil?
	#instance_password ||= $evm.root.decrypt('dialog_instance_password')
  
  	database_vm = $evm.root['miq_provision'].options[:database_vm]
    unless database_vm.nil?
      $evm.log("info","database_vm => #{database_vm}")
    end
  
 #   stp_task = $evm.root["service_template_provision_task"]	
 #   stp_dialog_options = stp_task.get_option(:dialog)
 #   $evm.log(:info, "nick => #{stp_dialog_options.inspect}")
  
 #  	$evm.log("info","dialog_instance1_name => #{options["dialog_instance1_name"]}")
	# $evm.log("info","dialog_instance1_port => #{options["dialog_instance1_port"]}")

	# Create category
	# @category_name = 'db_slots'
	#unless $evm.execute('category_exists?', @category_name)
	#	log(:info, "#{@method} - Category <#{@category_name}> doesn't exist, creating category")
	#	$evm.execute('category_create', :name => @category_name, :single_value => false, :description => 'Database Slots')
	#end

	#############################
	# Create the host via Foreman
	#############################

	# Get_Hostgroup_id_by_Name
	headers = {"Content-Type" => 'application/json', "Accept" => 'application/json;version=2'}

    if @type == 'application'
    	uri = "#{uri_base}/hostgroups?search=name=Uniserv"
    else
    	uri = "#{uri_base}/hostgroups?search=name=BGP_DB2"
    end

	# uri = "#{uri_base}/hostgroups?search=name=BGP_DB2"
	log(:info, "uri => #{uri}") if @debug

	# body={}

	request = RestClient::Request.new(
		method: :get,
		url: uri,
		headers: headers
	)

	json=request.execute
	log(:info, "rest_return => #{json.inspect}")
	data=JSON.parse(json)
	results=data["results"][0]

 	# Prepare host information  
   	hostinfo = {}

  	log(:info, 'Creating host')

	hostinfo[:name] = "#{vm.name}"
	#hostinfo[:environment_id] = '1'
	hostinfo[:mac] = "#{vm.mac_addresses[0]}"
	hostinfo[:architecture_id] = '1'
	hostinfo[:operatingsystem_id] = '1'
	hostinfo[:location_id] = '2'
	hostinfo[:organization_id] = '1'
	hostinfo[:domain_id] = '1'
    hostinfo[:hostgroup_id] = (results["id"]).to_s
	hostinfo[:root_pass] = 'RedHat14'
	hostinfo[:ptable_id] = '7'
    hostinfo[:build] = 'true'

	body = { host: hostinfo }

	log(:info, "hostinfo => #{hostinfo}")

	headers = {'Content-Type' => 'application/json', 'Accept' => 'application/json;version=2'}
	uri = "#{uri_base}/hosts"
	log(:info, "uri => #{uri}") if @debug
    request = RestClient::Request.new(
		method: :post,
		url: uri,
		headers: headers,
		payload: body.to_json
	)

 	rest_return = request.execute
 	log(:info, "rest_return => #{rest_return.inspect}")

	#############################
	# Query via MAC to determine host id
	#############################

	log(:info, 'Querying host_id')

	headers = {"Content-Type" => 'application/json', "Accept" => 'application/json;version=2'}
	uri = "#{uri_base}/hosts?search=mac=#{vm.mac_addresses[0]}"

	body = {}

	log(:info, "uri => #{uri}") if @debug
	request = RestClient::Request.new(
		method: :get,
		url: uri,
		headers: headers
	)

	json=request.execute
	host_data=JSON.parse(json)
	results=host_data["results"][0]
	host_id=(results["id"]).to_s

	# host_id = '1'

	#############################
	# Set the host parameters
	#############################

	log(:info, 'Setting parameters')

	# Cater for existing database instance 1-4 dialogue
	for s in 1..4 do
		log(:info, "Iteration => #{s}")
		unless options["dialog_instance#{s}_name"].nil?
			if options["dialog_instance#{s}_name"].length > 0
				#instance_password ||= $evm.root.decrypt("dialog_instance#{s}_password")
              	instance_password = 'my_password'
				hash = { "instance#{s}_name" => options["dialog_instance#{s}_name"], "instance#{s}_port" => options["dialog_instance#{s}_port"], "instance#{s}_password" => instance_password}
			    if @type == 'application'
			    	hash["instance#{s}_host"] = database_vm
			    end

				# set_hostgroup(vm, slot, host_id, parameters_hash, instance_name, instance_port)
				set_hostgroup(vm, s.to_s, host_id, hash, options["dialog_instance#{s}_name"], options["dialog_instance#{s}_port"])
			end
		end
	end

	# Cater for new database\instance bundle dialogue
	unless options["dialog_instance_name"].nil?
		if options["dialog_instance_name"].length > 0
			#instance_password ||= $evm.root.decrypt('dialog_instance_password')
          	instance_password = 'my_password'
			# log(:info, "Single instance => #{options["dialog_instance_name"]}:#{options["dialog_instance_port"]}")
			hash = { 'instance1_name' => options["dialog_instance_name"], 'instance1_port' => options["dialog_instance_port"], 'instance1_password' => instance_password}
		    if @type == 'application'
              hash["instance1_host"] = database_vm
		    end

			set_hostgroup(vm, "1", host_id, hash, options["dialog_instance_name"], options["dialog_instance_port"])
		end
	end

	# if options["dialog_instance1_name"].length > 0
	# 	# log(:info, "First instance => #{options["dialog_instance1_name"]}:#{options["dialog_instance1_port"]}")
	# 	# set_hostgroup(vm,"1",host_id,options["dialog_instance1_name"],options["dialog_instance1_port"])
	# 	hash = { 'instance1_name' => options["dialog_instance1_name"], 'dialog_instance1_port' => options["dialog_instance1_port"], 'instance_password' => instance_password}
	# 	set_hostgroup(vm,"1",hash)
	# end
	# if options["dialog_instance2_name"].length > 0
	# 	# log(:info, "Second instance => #{options["dialog_instance2_name"]}:#{options["dialog_instance2_port"]}")
	# 	# set_hostgroup(vm,"2",host_id,options["dialog_instance2_name"],options["dialog_instance2_port"])
	# 	hash = { 'instance2_name' => options["dialog_instance2_name"], 'dialog_instance2_port' => options["dialog_instance2_port"], 'instance_password' => instance_password}
	# 	set_hostgroup(vm,"1",hash)
	# end
	# if options["dialog_instance3_name"].length > 0
 #  #     log(:info, "Third instance => #{options["dialog_instance3_name"]}:#{options["dialog_instance3_port"]}")
	# 	# set_hostgroup(vm,"3",host_id,options["dialog_instance3_name"],options["dialog_instance3_port"])
	# 	hash = { 'instance3_name' => options["dialog_instance3_name"], 'dialog_instance3_port' => options["dialog_instance3port"], 'instance_password' => instance_password}
	# 	set_hostgroup(vm,"3",hash)
	# end
	# if options["dialog_instance4_name"].length > 0
	# 	# log(:info, "Fourth instance => #{options["dialog_instance4_name"]}:#{options["dialog_instance4_port"]}")
	# 	# set_hostgroup(vm,"4",host_id,options["dialog_instance4_name"],options["dialog_instance4_port"])
	# 	hash = { 'instance4_name' => options["dialog_instance4_name"], 'dialog_instance4_port' => options["dialog_instance4_port"], 'instance_password' => instance_password}
	# 	set_hostgroup(vm,"4",hash)
	# end

	log(:info, 'Restarting VM')
	vm.stop
	sleep(3)
	vm.start

	10.times { log(:info, 'CloudForms Automate Method Ended') }
	exit MIQ_OK

rescue => err
	log(:error, "[#{err}]\n#{err.backtrace.join("\n")}")
	exit MIQ_ABORT

end
