begin

  # Method for logging
  def log(level, message)
    @method = '----- Query Available Instances -----'
    $evm.log(level, "#{@method} - #{message}")
  end

  @debug = true
  category_name = 'db_slots'
  # category_name = 'db2_slots'

  log(:info, 'CloudForms Automate Method Started')

  vm = $evm.root['vm']
  raise 'The VM object is empty' if vm.nil?

  # log(:info, "#{vm.inspect}")
  log(:info, "#{vm.tags.inspect}")
  
  used_instances = []
  log(:info, "Checking used instances")
  
  vm.tags.each do | tag |
    log(:debug, "Tag <#{tag}>") if @debug

    for instance in 1..4 do
      if tag.match("#{category_name}/#{instance}")
        log(:info, "==> Instance #{instance} in use")
        used_instances << instance
      end
    end

    # case
    #   when tag.match("#{category_name}/1")
    #     log(:info, "==> Instance 1 in use")
    #     used_instances << 1

    #   when tag.match("#{category_name}/2")
    #     log(:info, "==> Instance 2 in use")
    #     used_instances << 2

    #   when tag.match("#{category_name}/3")
    #     log(:info, "==> Instance 3 in use")
    #     used_instances << 3

    #   when tag.match("#{category_name}/4")
    #     log(:info, "==> Instance 4 in use")
    #     used_instances << 4

    #   else
    #     log(:info, "==> Skipping unrelated tag")
    # end
  end

  # Determine available slots
  available_instances = []

  log(:info, "Determining available instances")

  if not used_instances.include?(1)
      log(:info, "==> Slot 1 available")
      available_instances << '1'
  end

  if not used_instances.include?(2)
      log(:info, "==> Slot 2 available")
      available_instances << '2'
  end

  if not used_instances.include?(3)
      log(:info, "==> Slot 3 available")
      available_instances << '3'
  end

  if not used_instances.include?(4)
      log(:info, "==> Slot 4 available")
      available_instances << '4'
  end

  if available_instances.empty?
    available_instances << 'No available slots'.reverse
  end

  dialog_field = $evm.object
  dialog_field['sort_order'] = 'ascending'
  dialog_field['data_type'] = 'array'
  dialog_field['required'] = 'true'
  dialog_field['default_value'] = available_instances[0]
  dialog_field['values'] = available_instances

  log(:info, 'CloudForms Automate Method Ended')
  exit MIQ_OK

# Set Ruby rescue behaviour
rescue => err

  log(:error, "[#{err}]\n#{err.backtrace.join("\n")}")
  send_email(vm, owner, 'Failed', "The following error has occurred '#{err}'")
  exit MIQ_ABORT

end
