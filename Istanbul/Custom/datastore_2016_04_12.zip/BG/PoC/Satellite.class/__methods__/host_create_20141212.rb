#
# Description: <Method description here>
#

begin

	# Method for logging
	def log(level, message)
		@method = '----- foreman host create -----'
		$evm.log(level, "#{@method} - #{message}")
	end

	log(:info, 'CloudForms Automate Method Started')
	@debug = true

	require 'rest-client'
	require 'json'
	require 'openssl'

	uri = "https://admin:RedHat14@satellite.plus.local/api/v2/hosts"
	log(:info, "uri => #{uri}") if @debug

	prov = $evm.root['miq_provision']
	# prov = $evm.root['miq_provision'] || $evm.root['miq_provision_request'] || $evm.root['miq_provision_request_template']
	# log(:info, "prov.inspect => #{prov.inspect}")
	log(:info, "prov.vm.inspect => #{prov.vm.inspect}")

	vm = prov.vm unless prov.nil?
	raise 'The VM object is empty' if vm.nil?

	# log(:info, "vm.inspect => #{vm.inspect}")

	hostinfo = {}
	hostinfo[:name] = "#{vm.name}"
	hostinfo[:environment_id] = '1'
	hostinfo[:mac] = "#{vm.mac_addresses[0]}"
	hostinfo[:architecture_id] = '1'
	hostinfo[:operatingsystem_id] = '1'
	hostinfo[:location_id] = '2'
	hostinfo[:organization_id] = '1'
	hostinfo[:domain_id] = '1'
	hostinfo[:hostgroup_id] = '1'
	hostinfo[:root_pass] = 'RedHat14'
	hostinfo[:ptable_id] = '7'
	hostinfo[:build] = 'true'
    hostinfo[:ip] = prov.get_option(:ip_addr)

    body = { host: hostinfo }
	log(:info, "hostinfo => #{hostinfo}")

	headers = {'Content-Type' => 'application/json', 'Accept' => 'application/json;version=2'}

	request = RestClient::Request.new(
		method: :post,
		url: uri,
		headers: headers,
		payload: body.to_json
	)

 	puts request.execute

    vm.stop
    vm.start

	log(:info, 'CloudForms Automate Method Ended')
	exit MIQ_OK

rescue => err
	log(:error, "[#{err}]\n#{err.backtrace.join("\n")}")
	exit MIQ_ABORT

end
