begin

  require 'rest-client'
  require 'json'
  require 'nokogiri'
  require 'openssl'

  @satellite_user = 'admin'
  @satellite_password = 'RedHat14'
  @satellite_host = 'satellite.plus.local'
  @satellite_uribase = "https://#{@satellite_user}:#{@satellite_password}@#{@satellite_host}/api/v2"

  #TODO get this name from vm object
  #host='lf42040.plus.local'

  headers = {"Content-Type" => 'application/json', "Accept" => 'application/json;version=2'}

  # Method for logging
  def log(level, message)
    @method = '----- Delete Satellite Registration -----'
    $evm.log(level, "#{@method} - #{message}")
  end 

  # ----------------------------------------------------------------------------
  # Get host name from VM object
  
  vm = $evm.root['vm']
  log(:info, "vm.inspect => #{vm.inspect}")
  raise 'The VM object is empty' if vm.nil?
  $evm.log(:info, "vm.inspect => #{vm.inspect}")
    
  hostname = "#{vm.name}" + ".plus.local"
  
  # ----------------------------------------------------------------------------
  # Get host ID from Satellite by host name and delete host by ID
  
  uri = "#{@satellite_uribase}/hosts/?search=name=#{hostname}"

  request = RestClient::Request.new(
    method: :get,
    url: uri,
    headers: headers
  )

  json=request.execute
  results=JSON.parse(json)
  hostdata=results["results"][0]
  hostid=(hostdata["id"]).to_s
  uri = "#{@satellite_uribase}/hosts/#{hostid}"
  #puts uri.inspect

  request = RestClient::Request.new(
    method: :delete,
    url: uri,
    headers: headers
  )

  result=request.execute
rescue => err
  log(:error, "[#{err}]\n#{err.backtrace.join("\n")}")
  exit MIQ_ABORT
end
