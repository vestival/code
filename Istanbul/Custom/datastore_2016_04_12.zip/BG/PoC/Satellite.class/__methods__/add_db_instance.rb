#
# Description: <Method description here>
#

begin

	# Method for logging
	def log(level, message)
		@method = '----- Add DB Instances -----'
		$evm.log(level, "#{@method} - #{message}")
	end

	# Method for adding new host to specified host group
	def set_parameters(vm, slot, host_id, instance_name, instance_port)

      	uri = "#{@uri_base}/hosts/#{host_id}/parameters"
		log(:info, "uri => #{uri}") if @debug

		headers = {'Content-Type' => 'application/json', 'Accept' => 'application/json;version=2'}

		# Create instance_name
		request = RestClient::Request.new(
			method: :post,
			url: uri,
			headers: headers,
          payload: {:name => "instance#{slot}_name", :value => instance_name}.to_json
		)

	 	rest_return = request.execute
	 	log(:info, "rest_return => #{rest_return.inspect}")

	 	# Create instance_port
 		request = RestClient::Request.new(
			method: :post,
			url: uri,
			headers: headers,
			payload: {:name => "instance#{slot}_port", :value => instance_port}.to_json
		)

	 	rest_return = request.execute
	 	log(:info, "rest_return => #{rest_return.inspect}")

	 	# Create necessary tag
	 	tag = slot + '_' + instance_name.downcase + '_' + instance_port
	 	log(:info, "tag => #{tag}") if @debug

		unless $evm.execute('tag_exists?', @category_name, tag)
			log(:info, "#{@method} - Creating <#{@category_name}/#{tag}> tag")
			$evm.execute('tag_create', @category_name, :name => tag, :description => tag)
		end
      
      	# Tag the VM
      	vm.tag_assign("#{@category_name}/#{tag}")

	end

	# Start

	log(:info, 'CloudForms Automate Method Started')
  	10.times { log(:info, '============================================') }
	@debug = true

	require 'rest-client'
	require 'json'
	require 'openssl'

	@satellite_user = 'admin'
	@satellite_password = 'RedHat14'
	@satellite_host = 'satellite.plus.local'
	@uri_base = "https://#{@satellite_user}:#{@satellite_password}@#{@satellite_host}/api/v2"

	vm = $evm.root['vm']
	log(:info, "vm.inspect => #{vm.inspect}")
	raise 'The VM object is empty' if vm.nil?
  
  	$evm.log("info","Slot => #{$evm.root['dialog_available_instances']}")
	$evm.log("info","Instance Name => #{$evm.root['dialog_instance_name']}")
	$evm.log("info","Instance Port => #{$evm.root['dialog_instance_port']}")

	if $evm.root['dialog_available_instances'].match(/[^1-4]/)
		log(:info, 'Valid slot not specified, exiting gracefully')
		log(:info, 'CloudForms Automate Method Ended')
		exit MIQ_OK
	end

	@category_name = 'db_slots'
	# @category_name = 'db2_slots'
	unless $evm.execute('category_exists?', @category_name)
		log(:info, "#{@method} - Category <#{@category_name}> doesn't exist, creating category")
		$evm.execute('category_create', :name => @category_name, :single_value => false, :description => 'Database Slots')
	end

	#############################
	# Query foreman for host_id by MAC
	#############################

	log(:info, 'Querying host_id')

	headers = {"Content-Type" => 'application/json', "Accept" => 'application/json;version=2'}
	uri = "#{@uri_base}/hosts?search=mac=#{vm.mac_addresses[0]}"
	log(:info, "uri => #{uri}") if @debug
	
	request = RestClient::Request.new(
		method: :get,
		url: uri,
		headers: headers
	)

	json = request.execute
	log(:info, "rest_return => #{json.inspect}")
	host_data	= JSON.parse(json)
	results		= host_data["results"][0]
	host_id		=(results["id"]).to_s
	# host_id = '1'

	#############################
	# Set the host parameters
	#############################

	log(:info, 'Setting instance parameters')
	set_parameters(vm, $evm.root['dialog_available_instances'], host_id, $evm.root['dialog_instance_name'], $evm.root['dialog_instance_port'])

	log(:info, 'CloudForms Automate Method Ended')
	exit MIQ_OK

rescue => err
	log(:error, "[#{err}]\n#{err.backtrace.join("\n")}")
	exit MIQ_ABORT

end
