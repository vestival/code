#############################
# BG Pheonics logic...
#############################

# Method for logging
def log(level, message)
  @method = '----- BG Bundle Catalogue Initialisation -----'
  $evm.log(level, "#{@method} - #{message}")
end

#add_instance(vm, 'database', database_slot, hash, instance_name, instance_port)

def add_instance(vm, function, slot, parameters_hash, instance_name, instance_port)

  @debug = true

  case
    when function == 'database'
      # @category_name = 'db_slots'
      @category_name = 'db_slots'
    when function == 'application'
      @category_name = 'app_slots'   
  end

  #unless $evm.execute('category_exists?', @category_name)
  #  log(:info, "#{@method} - Category <#{@category_name}> doesn't exist, creating category")
  #  $evm.execute('category_create', :name => @category_name, :single_value => false, :description => "#{function.Capitalize} Slots")
  #end

  # return

  require 'rest-client'
  require 'json'
  require 'openssl'

  @satellite_user = 'admin'
  @satellite_password = 'RedHat14'
  @satellite_host = 'satellite.plus.local'
  @uri_base = "https://#{@satellite_user}:#{@satellite_password}@#{@satellite_host}/api/v2"

  # vm = $evm.root['vm']
  # log(:info, "vm.inspect => #{vm.inspect}")
  raise 'The VM object is empty' if vm.nil?

  # unless $evm.execute('category_exists?', @category_name)
  #   log(:info, "#{@method} - Category <#{@category_name}> doesn't exist, creating category")
  #   $evm.execute('category_create', :name => @category_name, :single_value => false, :description => 'Database Slots')
  # end

  #############################
  # Query foreman for host_id by MAC
  #############################

  log(:info, 'Querying host_id')

  headers = {"Content-Type" => 'application/json', "Accept" => 'application/json;version=2'}
  uri = "#{@uri_base}/hosts?search=mac=#{vm.mac_addresses[0]}"
  log(:info, "uri => #{uri}") if @debug
  
  request = RestClient::Request.new(
    method: :get,
    url: uri,
    headers: headers
  )

  json    = request.execute
  log(:info, "rest_return => #{json.inspect}")
  host_data = JSON.parse(json)
  results   = host_data["results"][0]
  host_id   =(results["id"]).to_s
  # host_id = '1'

  #############################
  # Set the host parameters
  #############################

  log(:info, 'Setting instance parameters')

  uri = "#{@uri_base}/hosts/#{host_id}/parameters"
  log(:info, "uri => #{uri}") if @debug

  headers = {'Content-Type' => 'application/json', 'Accept' => 'application/json;version=2'}

parameters_hash.each do |k, v|

	log(:info, "#{k} => #{v}") 
	request = RestClient::Request.new(
		method: :post,
		url: uri,
		headers: headers,
      payload: {:name => k, :value => v}.to_json
	)

 	rest_return = request.execute
 	log(:info, "rest_return => #{rest_return.inspect}")
end

  # Create necessary tag
  tag = slot + '_' + instance_name.downcase + '_' + instance_port
  log(:info, "tag => #{tag}") if @debug

  unless $evm.execute('tag_exists?', @category_name, tag)
    log(:info, "Creating <#{@category_name}/#{tag}> tag")
    $evm.execute('tag_create', @category_name, :name => tag, :description => tag)
  end
  
  # Tag the VM
  log(:info, "Tagging VM with <#{@category_name}/#{tag}>")
  vm.tag_assign("#{@category_name}/#{tag}")

 end

# Start...

10.times { $evm.log(:info, "*********************************************************************") }

# Take dialogue options, db instance, port and password

instance_name = $evm.root['dialog_instance_name']
instance_port = $evm.root['dialog_instance_port']
instance_password = $evm.root['dialog_instance_password']
database_required = $evm.root['dialog_database_required']
$evm.log(:info, "Instance Name => #{instance_name}")
$evm.log(:info, "Instance Port => #{instance_port}")
$evm.log(:info, "Instance Password => #{instance_password}") # Password needs decrypting

# Query all lf database and application VMs for an available 'slot'

max_slots = 4

database_required = false
database_slot = nil
database_determined = false
database_vm = nil
application_required = false
application_slot = nil
application_determined = false
application_vm = nil

#grp = $evm.vmdb('miq_group').find_by_id(g)
# vms = $evm.vmdb('vm').find_by_id(tag)

vms = $evm.vmdb('vm').all
$evm.log(:info, "vms.count => #{vms.count}")

#############################
# Determine database VM first
#############################

eligible_vms = []
used_instances = []

# Not efficient but we'll iterate vms twice as we need to determine database VM first
vms.each do |vm|
  if vm.name.match(/^lf42/i)
  # if vm.name.match(/^lf/i)

    eligible_vms << vm.name

    # orphaned = vm.send(:orphaned)
    # log(:info, "orphaned <#{orphaned}>")
    # archived = vm.send(:archived)
    # log(:info, "archived <#{archived}>")

    if vm.send(:orphaned) == true
      log(:info, "SKIPPING orphaned VM <#{vm.name}>")
      next
    elsif vm.send(:archived) == true
      log(:info, "SKIPPING archived VM <#{vm.name}>")
      next
    end

    if vm.retired
      log(:info, "SKIPPING retired VM <#{vm.name}>")
      next
    end

    # eligible_vms << vm.name

    $evm.log(:info, "Checking VM => #{vm.name}")

    function = vm.tags(:function)
    log(:info, "function tags: #{function.inspect}")
    # log(:info, "function methods: #{function.methods.inspect}")

    if function.include?('database') and database_determined == false

      used_slots = vm.tags(:db_slots)
      # used_slots = vm.tags(:db2_slots)
      if used_slots.nil?
        log(:info, "Found database with no used slots, invalid use case but we need to catch and try next")
        next
      end
      
      log(:info, "used_slots: #{used_slots.inspect}")

      if used_slots.count == max_slots
        log(:info, "All DB slots used on #{vm.name}, try next")
        # Try next VM or if no more, provision new DB VM with a slot
        # Set 'slot' to 1 (perhaps assume slot 1?)
        # Use dialogue values for instance, port and password
        next

      else
        log(:info, "Available DB slots on #{vm.name}")
        # Use this DB VM and available slot
        # Set first available 'slot'
        # Use dialogue values for instance, port and password
        # Remove DB catalogue item

        category_name = 'db_slots'
        vm.tags.each do | tag |
          log(:debug, "Tag <#{tag}>") #if @debug

          for instance in 1..4 do
            if tag.match("#{category_name}/#{instance}")
              log(:info, "==> Instance #{instance} in use")
              used_instances << instance
            end
          end
        end
        
        if used_instances.count == max_slots
          log(:info, "No free slots, trying next")
          next
        end

        for instance in 1..4 do
          if not used_instances.include?(instance)
              log(:info, "==> Slot #{instance} available")
              # log(:info, "vm.inspect: #{vm.inspect}")
              database_slot = instance.to_s
              database_determined = true
              database_vm = vm.name
              break
              # available_instances << instance.to_s
          end
        end
        hash = { "instance#{database_slot}_name" => instance_name, "instance#{database_slot}_port" => instance_port, "instance#{database_slot}_password" => 'my_password'}
        add_instance(vm, 'database', database_slot, hash, instance_name, instance_port)

        if database_determined == true
          break
        end

      end
    end
  else
    # $evm.log(:info, "Skipping VM => #{vm.name}")
  end
end

if database_determined == false
  $evm.log(:info, "Database with available slots not determined, new VM will be deployed")
  eligible_vms = eligible_vms.sort.uniq
  $evm.log(:info, "'lf42' VM count => #{eligible_vms.count}")
  $evm.log(:info, "#{eligible_vms.inspect}")
  last_eligible_vm = eligible_vms[-1]
  next_eligible_vm = last_eligible_vm.succ
  $evm.log(:info, "next_eligible_vm => #{next_eligible_vm}")

  database_required = true
  database_slot = '1'
  database_determined = true
  database_vm = next_eligible_vm
end

#############################
# Determine application VM first
#############################

eligible_vms = []
used_instances = []

vms.each do |vm|
  if vm.name.match(/^lf42/i)
  # if vm.name.match(/^lf/i)

    # orphaned = vm.send(:orphaned)
    # log(:info, "orphaned <#{orphaned}>")
    # archived = vm.send(:archived)
    # log(:info, "archived <#{archived}>")

    if vm.send(:orphaned) == true
      log(:info, "SKIPPING orphaned VM <#{vm.name}>")
      next
    elsif vm.send(:archived) == true
      log(:info, "SKIPPING archived VM <#{vm.name}>")
      next
    end

    if vm.retired
      log(:info, "SKIPPING retired VM <#{vm.name}>")
      next
    end

    eligible_vms << vm.name

    $evm.log(:info, "Checking VM => #{vm.name}")

    function = vm.tags(:function)
    log(:info, "function tags: #{function.inspect}")
    # log(:info, "function methods: #{function.methods.inspect}")

    if function.include?('application_servers') and application_determined == false

      used_slots = vm.tags(:db_slots)
      # used_slots = vm.tags(:db2_slots)
      if used_slots.nil?
        log(:info, "Found application with no used slots, invalid use case but we need to catch and try next")
        next
      end
      
      log(:info, "used_slots: #{used_slots.inspect}")

      if used_slots.count == max_slots
        log(:info, "All DB slots used on #{vm.name}, try next")
        # Try next VM or if no more, provision new DB VM with a slot
        # Set 'slot' to 1 (perhaps assume slot 1?)
        # Use dialogue values for instance, port and password
        next

      else
        log(:info, "Available DB slots on #{vm.name}")
        # Use this DB VM and available slot
        # Set first available 'slot'
        # Use dialogue values for instance, port and password
        # Remove DB catalogue item

        category_name = 'app_slots'
        vm.tags.each do | tag |
          log(:debug, "Tag <#{tag}>") #if @debug

          for instance in 1..4 do
            if tag.match("#{category_name}/#{instance}")
              log(:info, "==> Instance #{instance} in use")
              used_instances << instance
            end
          end
        end
        
        if used_instances.count == max_slots
          log(:info, "No free slots, trying next")
          next
        end

        for instance in 1..4 do
          if not used_instances.include?(instance)
              log(:info, "==> Slot #{instance} available")
              # log(:info, "vm.inspect: #{vm.inspect}")
              application_slot = instance.to_s
              application_determined = true
              application_vm = vm.name
              break
              # available_instances << instance.to_s
          end
        end
        hash = { "instance#{application_slot}_name" => instance_name, "instance#{application_slot}_port" => instance_port, "instance#{application_slot}_password" => 'my_password'}
        add_instance(vm, 'application', application_slot, hash, instance_name, instance_port)

        if application_determined == true
          break
        end

      end
    end
  else
    # $evm.log(:info, "Skipping VM => #{vm.name}")
  end
end

if application_determined == false
  $evm.log(:info, "application with available slots not determined, new VM will be deployed")
  eligible_vms = eligible_vms.sort.uniq
  $evm.log(:info, "'lf42' VM count => #{eligible_vms.count}")
  $evm.log(:info, "#{eligible_vms.inspect}")
  last_eligible_vm = eligible_vms[-1]
  next_eligible_vm = last_eligible_vm.succ
  if database_required == true
    $evm.log(:info, "If we need to deploy a DB server, then we need to iterate once more")
    next_eligible_vm = next_eligible_vm.succ
  end
  $evm.log(:info, "next_eligible_vm => #{next_eligible_vm}")

  application_required = true
  application_slot = '1'
  application_determined = true
  application_vm = next_eligible_vm
end

#############################
# Finalise requirements
#############################

5.times { $evm.log(:info, "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx") }
$evm.log(:info, "database_required => #{database_required}")
$evm.log(:info, "database_slot => #{database_slot}")
$evm.log(:info, "database_determined => #{database_determined}")
$evm.log(:info, "database_vm => #{database_vm}")
$evm.log(:info, "application_required => #{application_required}")
$evm.log(:info, "application_slot => #{application_slot}")
$evm.log(:info, "application_determined => #{application_determined}")
$evm.log(:info, "application_vm => #{application_vm}")
5.times { $evm.log(:info, "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx") }


# If slot available on database VM, assign using Foreman (via REST) and drop database catalogue item from service request,
# otherwise, assign first slot using Foreman (via REST) and provision.

# If slot available on application VM, assign using Foreman (via REST) and drop application catalogue item from service request
# otherwise, assign first slot using Foreman (via REST) and provision.

10.times { $evm.log(:info, "*********************************************************************") }

#
#
# Description: This method sets the dialog optioms in the destination service and service catalog items.
# 1. Look for all Service Dialog Options in the service_template_provision_task.dialog_options
#    (i.e. Options that come from a Service Dialog)
# 2. Any Service dialog option keys that match the regular expression /^tag_0_(.*)/i will be used to
#    tag the destination Service
# 3. Service dialog option keys that match the regular expression /^(option|tag)_(\d*)_(.*)/
#    (I.e. <option_type>_<sequence_id>_variable,  option_0_vm_memory, tag_1_environment) are sorted
#    by sequence_id into an options_hash[sequence_id] and then distributed to the appropriate
#    child catalog items. For example, a sequence_id of 0 means that all catalog items will inhereit
#    these variables. A sequence_id of 1 means that the variable is only intended for a catalog item
#    with a group index of 1.
# 4. Service dialog option keys that do NOT match the regular expression are then inserted into the
#    options_hash[0] for all catalog items.
#
# Inputs: $evm.root['service_template_provision_task'].dialog_options
#

# Description: Look for service dialog variables in the root object that start with "dialog_option_[0-9]",
def get_options_hash(dialog_options)
  # Setup regular expression for service dialog tags
  options_regex = /^(dialog_option|dialog_tag)_(\d*)_(.*)/i
  options_hash = {}

  # Loop through all of the options and build an options_hash from them
  dialog_options.each do |k, v|

    option_key = k.downcase.to_sym
    if options_regex =~ k
      sequence_id = Regexp.last_match[2].to_i

      unless v.blank?
        $evm.log("info", "Adding sequence_id:<#{sequence_id}> option_key:<#{option_key.inspect}> v:<#{v.inspect}> to options_hash")
        if options_hash.key?(sequence_id)
          options_hash[sequence_id][option_key] = v
        else
          options_hash[sequence_id] = {option_key => v}
        end
      end
    else
      # If options_regex does not match then stuff dialog options into options_hash[0]
      sequence_id = 0
      unless v.nil?
        $evm.log("info", "Adding sequence_id:<#{sequence_id}> option_key:<#{option_key.inspect}> v:<#{v.inspect}> to options_hash")
        if options_hash.key?(sequence_id)
          options_hash[sequence_id][option_key] = v
        else
          options_hash[sequence_id] = {option_key => v}
        end
      end
    end # if options_regex =~ k
  end # dialog_options.each do
  $evm.log("info", "Inspecting options_hash:<#{options_hash.inspect}>")
  options_hash
end

# Description: Look for tags with a sequence_id of 0 and tag the parent service
def tag_parent_service(service, options_hash)
  # Setup regular expression for service dialog tags
  tags_regex = /^dialog_tag_0_(.*)/i

  # Look for tags with a sequence_id of 0 to tag the destination Service
  options_hash[0].each do |k, v|
    $evm.log("info", "Processing Tag Key:<#{k.inspect}> Value:<#{v.inspect}>")
    if tags_regex =~ k
      # Convert key to symbol
      tag_category = Regexp.last_match[1]
      tag_value = v.downcase
      unless tag_value.blank?
        $evm.log("info", "Adding tag_category:<#{tag_category.inspect}> value:<#{tag_value.inspect}> to Service:<#{service.name}>")
        service.tag_assign("#{tag_category}/#{tag_value}")
      end
    end # if tags_regex
  end # options_hash[0].each
end

# Get the task object from root
service_template_provision_task = $evm.root['service_template_provision_task']

# Get destination service object
service = service_template_provision_task.destination
$evm.log("info", "Detected Service:<#{service.name}> Id:<#{service.id}>")

# Get dialog options from options hash
# I.e. {:dialog=>{"option_0_myvar"=>"myprefix", "option_1_vservice_workers"=>"2", "tag_0_environment"=>"test", "tag_0_location"=>"paris",
# "option_2_vm_memory"=>"2048", "option_0_vlan"=>"Internal", "option_1_cores_per_socket"=>"1"}}
dialog_options = service_template_provision_task.dialog_options
$evm.log("info", "Inspecting Dialog Options:<#{dialog_options.inspect}>")

# Get options_hash
options_hash = get_options_hash(dialog_options)

# Tag Parent Service
tag_parent_service(service, options_hash)

# Process Child Services
service_template_provision_task.miq_request_tasks.each do |t|
  # Child Service
  child_service = t.destination
  # Service Bundle Resource
  child_service_resource = t.service_resource

  # Increment the provision_index number since the child resource starts with a zero
  group_idx = child_service_resource.provision_index + 1
  $evm.log("info", "Child service name:<#{child_service.name}> group_idx:<#{group_idx}>")

  # Create dialog options hash variable
  dialog_options_hash = {}

  # Set all dialog options pertaining to the catalog item plus any options destined for the catalog bundle
  unless options_hash[0].nil?
    unless options_hash[group_idx].nil?
      # Merge child options with global options if any
      dialog_options_hash = options_hash[0].merge(options_hash[group_idx])
    else
      dialog_options_hash = options_hash[0]
    end
  else # unless options_hash[0].nil?
    unless options_hash[group_idx].nil?
      dialog_options_hash = options_hash[group_idx]
    end
  end

  # Pass down dialog options to catalog items
  dialog_options_hash.each do |k, v|
    $evm.log("info", "Adding Dialog Option:<{#{k.inspect} => #{v.inspect}}> to Child Service:<#{child_service.name}>")
    t.set_dialog_option(k, v)
  end

  #############################
  # Pass down custom options to catalog items
  #############################  
  # t.set_dialog_option('nick_woz_ere', true)
  t.set_dialog_option(:database_required, database_required)
  t.set_dialog_option(:application_required, application_required)
  t.set_dialog_option(:application_slot, application_slot)
  t.set_dialog_option(:database_slot, database_slot)
  t.set_dialog_option(:database_vm, database_vm)

  $evm.log("info", "Inspecting Child Service:<#{child_service.name}> Dialog Options:<#{t.dialog_options.inspect}>")
end
