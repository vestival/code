	#
	# Description: <Method description here>
	#

	begin

		def mark_task_invalid(task)
		  task.finished("Invalid")
		  task.miq_request_tasks.each do |t|
		    2.times { $evm.log(:info, "******************************** DUMPING TASK <#{t}> *************************************") }
		    $evm.log(:info, "#{t.description}")
		    mark_task_invalid(t)
		  end
		end

		$evm.log(:info, 'CloudForms Automate Method Started')

		10.times { $evm.log(:info, "*********************************************************************") }

		stp_task = $evm.root["service_template_provision_task"]
		miq_request_id = $evm.vmdb('miq_request_task', stp_task.get_option(:parent_task_id))
		dialogOptions = miq_request_id.get_option(:dialog)

		4.times { $evm.log(:info, "ssssssssssssssssssssssssssssssssssssssss") }
      	service_template_provision_task = $evm.root['service_template_provision_task']
		# $evm.root['service_template_provision_task'].options[:dialog] = {:dialog_instance_name=>"junglist", :dialog_instance_port=>"60000", :"password::dialog_instance_password"=>"v2:{OzogLu0OXLLcWBSuz4rrZA==}", :request=>"clone_to_service", :database_required=>false, :application_required=>false, "request"=>"clone_to_service"}
		$evm.log(:info, $evm.root['service_template_provision_task'].options[:dialog].inspect)
		stp_dialog_options = stp_task.get_option(:dialog)
        $evm.log(:info, "#{stp_dialog_options.inspect}")

		$evm.log(:info, "database_required <#{stp_dialog_options[:database_required]}>")
		$evm.log(:info, "application_required <#{stp_dialog_options[:application_required]}>")
		4.times { $evm.log(:info, "ssssssssssssssssssssssssssssssssssssssss") }

		# $evm.log(:info, "Dialog_Environment #{dialogOptions['dialog_environment'].downcase}")
		# $evm.log(:info, "State_Environment #{$evm.root['State_Environment'].downcase}")

		# if dialogOptions['dialog_environment'].downcase != $evm.root['State_Environment'].downcase
		#   $evm.log(:info, "NO MATCH - DUMPING Service from resolution")
		#   task = $evm.root["service_template_provision_task"]
		#   mark_task_invalid(task)
		#   exit MIQ_STOP
		# end

		if stp_dialog_options[:database_required] == false and $evm.root['state_item'] == 'database'
		  $evm.log(:info, "Database service item not required, dropping task")
		  task = $evm.root["service_template_provision_task"]
		  mark_task_invalid(task)
		  exit MIQ_STOP
		end

		if stp_dialog_options[:application_required] == false and $evm.root['state_item'] == 'application'
		  $evm.log(:info, "Application service item not required, dropping task")
		  task = $evm.root["service_template_provision_task"]
		  mark_task_invalid(task)
		  exit MIQ_STOP
		end

		# $evm.log(:info, "MATCH FOUND - Processing Service Normally")

		10.times { $evm.log(:info, "*********************************************************************") }

		$evm.log(:info, 'CloudForms Automate Method Ended')
		exit MIQ_OK

	rescue => err
		$evm.log(:error, "[#{err}]\n#{err.backtrace.join("\n")}")
		exit MIQ_ABORT

	end
