#
# Description: This method is used to Customize the VMware and VMware PXE Provisioning Request
#

# Get provisioning object
prov = $evm.root["miq_provision"]
vm_target_name = prov.options[:vm_target_name]
$evm.log(:info, "vm_target_name => #{vm_target_name}")

10.times { $evm.log(:info, "##############################################################") }

if vm_target_name.match(/^lf/i)

  $evm.log(:info, "'lf' VM name suffix detected, overriding to use next available...")
  
  vms = $evm.vmdb('vm').all
  allvms = []
  vms.each do |vm|
    if vm.name.match(/^lf/i)
      allvms << vm.name
    end
  end
  
  allvms = allvms.sort.uniq
  $evm.log(:info, "'lf' VM count => #{allvms.count}")
  $evm.log(:info, "#{allvms.inspect}")
  last_name = allvms[-1]
  next_name = last_name.chomp('.plus.local')
  next_name = next_name.succ
  $evm.log(:info, "next_name => #{next_name}")

  prov.set_option(:vm_target_name,next_name)
  
end

$evm.log("info", "Provisioning ID:<#{prov.id}> Provision Request ID:<#{prov.miq_provision_request.id}> Provision Type: <#{prov.provision_type}>")

