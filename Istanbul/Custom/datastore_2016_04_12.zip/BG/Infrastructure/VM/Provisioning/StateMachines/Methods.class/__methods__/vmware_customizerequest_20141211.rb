#
# Description: This method is used to Customize the VMware and VMware PXE Provisioning Request
#

# Get provisioning object
prov = $evm.root["miq_provision"]

vm_target_name = prov.get_option(:vm_target_name)
suffix = Time.now.strftime("%H%M%S")
new_vm_target_name = vm_target_name + suffix
$evm.log("info", "new_vm_target_name - #{new_vm_target_name}")
prov.set_option(:vm_target_name,new_vm_target_name)

$evm.log("info", "Provisioning ID:<#{prov.id}> Provision Request ID:<#{prov.miq_provision_request.id}> Provision Type: <#{prov.provision_type}>")
