#
# Description: This method launches the VM migration job
#

$evm.root["vm_migrate_task"].execute
