require 'rest-client'
require 'json'
require 'nokogiri'
require 'openssl'


# ============================================================================
# Temporary values that need to be replaced by CF objects

prov = $evm.root['miq_provision']
	# prov = $evm.root['miq_provision'] || $evm.root['miq_provision_request'] || $evm.root['miq_provision_request_template']
	# log(:info, "prov.inspect => #{prov.inspect}")
    $evm.log(:info, "prov.vm.inspect => #{prov.vm.inspect}")

	vm = prov.vm unless prov.nil?
	raise 'The VM object is empty' if vm.nil?
		
hostname = "#{vm.name}" + ".plus.local"
mac = vm.mac_addresses[0]

#mac = '00:50:56:8e:b4:b7'
#hostname = 'lf42010.plus.local'

#uri = "#{satellite_uribase}/hosts?search=mac=#{vm.mac_addresses[0]}"
# ============================================================================

@satellite_user = 'admin'
@satellite_password = 'RedHat14'
@satellite_host = 'satellite.plus.local'
satellite_uribase = "https://#{@satellite_user}:#{@satellite_password}@#{@satellite_host}/api/v2"

@infoblox_user = 's50redhat'
@infoblox_password = 'RedHat14'
@infoblox_host = '10.148.208.38'
$infoblox_uribase = "https://#{@infoblox_user}:#{@infoblox_password}@#{@infoblox_host}/wapi/v1.2.1"

headers = {"Content-Type" => 'application/json', "Accept" => 'application/json;version=2'}

# Get grid ID from Infoblox
# The next seven lines have been taken from an other example script
        url = "#{$infoblox_uribase}/grid"
#puts "url #{url}"
        dooie = RestClient.get url
        doc = Nokogiri::XML(dooie)
        root = doc.root
        $grid = root.xpath("value/_ref/text()")[0]
        #puts "============ grid #{$grid}"

# Method for logging
        def log(level, message)
                #@method = '----- foreman host create -----'
                #$evm.log(level, "#{@method} - #{message}")
                #puts message.inspect
        end     # Method for logging


# Restart the Infoblox serviecs
def ibrestart()
                #$evm.log("info", "GetIP --> Grid Reference #{grid}")
                uri = "#{$infoblox_uribase}/" + $grid + '?_function=restartservices'
                #puts uri.inspect

        headers = {"Content-Type" => 'application/json', "Accept" => 'application/json;version=2'}
                body = {}

#body[:restart_option] = "RESTART_IF_NEEDED"
                body[:restart_option] = "FORCE"
                body[:service_option] = "ALL"
                body[:member_order] = "SEQUENTIALLY"
                body[:sequential_delay] = "1"

                request = RestClient::Request.new(
                        method: :post,
                        url: uri,
                        headers: headers,
                        payload: body.to_json
                )
                #puts "============ request body"
                #puts body.inspect
                #puts "============ restart #{request}"
                #puts request.inspect
end


# We do this once we put it in CFME

# This is for the dry run outside CFME
#        uri = "#{satellite_uribase}/hosts?search=mac=#{mac}"
#
#       log(:info, "uri => #{uri}") if @debug
#        request = RestClient::Request.new(
#                method: :get,
#                url: uri,
#              headers: headers
#        )
#
#        log(:info, "uri => #{uri}") if @debug
#        request = RestClient::Request.new(
#                method: :get,
#                url: uri,
#                headers: headers
#        )
#
#        json=request.execute
#        host_data=JSON.parse(json)
#        results=host_data["results"][0]
#        hostname=(results["name"]).to_s
#
#       #puts "============ hostname #{hostname}"

# Fetch dynamically assinged IP address from Infoblox

        #uri = "#{$infoblox_uribase}/search?objtype=lease&search_string=#{mac}"
        uri = "#{$infoblox_uribase}/search?search_string=#{mac}"
        request = RestClient::Request.new(
                method: :get,
                url: uri,
                headers: headers
        )

        #puts request.inspect
        json=request.execute
        #puts json.inspect
        results=JSON.parse(json)
        host_data=results[0]
        host_data["ipv4addr"].nil? ? hostaddr=host_data["address"] : hostaddr=host_data["ipv4addr"]
        #puts "====== host address: #{hostaddr}"
#       hostaddr=host_data["ipv4addr"].to_s
        #puts "============ hostaddr #{hostaddr}"

        # TODO This will need error handling for production usage.

# Register the dynamically assigned IP address as a host

        uri = "#{$infoblox_uribase}/fixedaddress"

        body = {}
        body[:mac] = mac
        body[:name] = hostname
        body[:comment] = hostname
        body[:ipv4addr] = hostaddr
        body[:network_view] = "default"

        #puts "=====body====="
        #puts body.inspect
        #puts body.to_json
    #puts uri
        request = RestClient::Request.new(
                method: :post,
                url: uri,
                headers: headers,
                payload: body.to_json
        )
        result=request.execute

# Register the host's adadress as DNS A record

        uri = "#{$infoblox_uribase}/record:a"

        body = {}
        body[:name] = "#{hostname}"
        body[:ipv4addr] = "#{hostaddr}"

        request = RestClient::Request.new(
                method: :post,
                url: uri,
                headers: headers,
                payload: body.to_json
        )
        result=request.execute
        #puts "============ record:a #{request}"
        #puts result.inspect

# Register the host's adadress as DNS PTR record

    #hostaddr="192.168.35.15"
        #puts "====== hostaddr #{hostaddr}"
        addr_help=hostaddr.split(".")
        #puts "====== addr_help[0]: #{addr_help[0]}"
        rev_addr=addr_help[3]+"."+addr_help[2]+"."+addr_help[1]+"."+addr_help[0]+".in-addr.arpa"
        #puts "====== rev_addr: #{rev_addr}"

        uri = "#{$infoblox_uribase}/record:ptr"
        body = {}
        body[:view] = "default"
        body[:name] = "#{rev_addr}"
        body[:ptrdname] = "#{hostname}"
        body[:ipv4addr] = "#{hostaddr}"

        request = RestClient::Request.new(
                method: :post,
                url: uri,
                headers: headers,
                payload: body.to_json
        )
        result=request.execute
        #puts "============ record:ptr #{request}"
        #puts result.inspect

        ibrestart()

        $evm.log("info", "GetIP --> Grid Restarting")
