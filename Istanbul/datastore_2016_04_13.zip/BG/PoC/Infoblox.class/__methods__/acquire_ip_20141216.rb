# 17 Sept 2013
# InfoBlox IPAM - Get IP Address
# Version 1.0
# -------------------------------------------------------
# Usage - Method belongs to InfoBlox StateMachine.
# -------------------------------------------------------
#
# https://10.148.208.38/wapi/v1.2.1/ipv4address?_return_fields=ip_address&network=10.148.208.0/27&mac_address=00:50:56:8e:aa:66


begin
  
$evm.log("info", "********* InfoBlox - GetIP STARTED *********")

require 'rest_client'
require 'json'
require 'nokogiri'
require 'ipaddr'


##################################
# Get IP Address		 #
##################################
def getIP(hostname, ipaddress, macaddress)
	begin
		url = 'https://' + @connection + '/wapi/v1.2.1/record:host'
		content = "\{\"ipv4addrs\":\[\{\"ipv4addr\":\"#{ipaddress}\",\"configure_for_dhcp\":true,\"mac\":\"#{macaddress}\"\}\],\"view\":\"default\",\"configure_for_dns\":true,\"name\":\"#{hostname}\"\}"
      $evm.log("info", "Infoblox content => #{content}")	
      # dooie = RestClient.post url, content, :content_type => :json, :accept => :json
		RestClient.post url, content, :content_type => :json, :accept => :json
		return true
	# rescue Exception => e
	# 	puts e.inspect
	# 	puts dooie
	# 	return false
	end
end

##################################
# Next Available IP Address      #
##################################
def nextIP(range)
        begin
		$evm.log("info", "GetIP --> NextIP on - #{range}")
                url = 'https://' + @connection + '/wapi/v1.2.1/' + range
                dooie = RestClient.post url, :_function => 'next_available_ip', :num => '1'
		doc = Nokogiri::XML(dooie)
                root = doc.root
                nextip = root.xpath("ips/list/value/text()")
		$evm.log("info", "GetIP --> NextIP is - #{nextip}")
                return nextip
        # rescue Exception => e
        #         puts e.inspect
        #         return false
        end
end


##################################
# Fetch Network Ref              #
##################################
def fetchRangeRef(cdir)
        begin
		$evm.log("info", "GetIP --> Network Search - #{cdir}")
               url = 'https://' + @connection + '/wapi/v1.2.1/range?network=' + cdir
          $evm.log("info", "url --> #{url}")
               dooie = RestClient.get url
		doc = Nokogiri::XML(dooie)
		root = doc.root
		ranges = root.xpath("value/_ref/text()")
		$evm.log("info", "ranges --> #{ranges}")
          ranges.each do | a |
			$evm.log("info", "ranges a --> #{a}")
            a = a.to_s
			#unless a.index('.100').nil?      
            unless a.index('.1').nil?
				$evm.log("info", "GetIP --> Range Found - #{a}")
				return a
			end
		end
	        return nil
        rescue Exception => e
            $evm.log("info", "e.inspect --> #{e.inspect}")
            # puts e.inspect
            return false
        end
end


##################################
# Restart Infoblox Grid          #
##################################
def restartGrid()
        begin
			$evm.log("info", "GetIP --> Restart Grid")
			url = 'https://' + @connection + '/wapi/v1.2.1/grid'
			dooie = RestClient.get url
			doc = Nokogiri::XML(dooie)
			root = doc.root
			grid = root.xpath("value/_ref/text()")[0]
			$evm.log("info", "GetIP --> Grid Reference #{grid}")
			url = 'https://' + @connection + '/wapi/v1.2.1/' + grid + '?_function=restartservices'
			content = "\{\"restart_option\":\"RESTART_IF_NEEDED\",\"service_option\":\"ALL\",\"member_order\":\"SEQUENTIALLY\",\"sequential_delay\":1\}"
			dooie = RestClient.post url, content, :content_type => :json, :accept => :json
			$evm.log("info", "GetIP --> Grid Restarting")
	    return nil
        # rescue Exception => e
        #     $evm.log("info", "e.inspect --> #{e.inspect}")
        #     # puts e.inspect
        #     $evm.log("info", "dooie --> #{dooie}")
        #     # puts dooie
        #     return false
        end
end


##################################
# Set netmask 	               #
##################################
def netmask(cdir)
  netblock = IPAddr.new(cdir)
  netins =  netblock.inspect
  netmask = netins.match(/(?<=\/)(.*?)(?=\>)/)
  $evm.log("info", "GetIP --> Netmask = #{netmask}")
  return netmask
end

##################################
# Set Options in prov			               #
##################################
def set_prov(prov, hostname, ipaddr, netmask, gateway, macaddress)
	$evm.log("info", "GetIP --> Hostname = #{hostname}")
	$evm.log("info", "GetIP --> IP Address =  #{ipaddr}")
	$evm.log("info", "GetIP -->  Netmask = #{netmask}")
	$evm.log("info", "GetIP -->  Gateway = #{gateway}")
	$evm.log("info", "GetIP -->  MAC Address = #{macaddress}")
	prov.set_option(:addr_mode, ["static", "Static"])
	prov.set_option(:ip_addr, "#{ipaddr}")
	prov.set_option(:mac_address, "#{macaddress}")
	prov.set_option(:subnet_mask, "#{netmask}")
    prov.set_option(:gateway, "#{gateway}")
	prov.set_option(:vm_target_name, "#{hostname}")
	prov.set_option(:linux_host_name, "#{hostname}")
	prov.set_option(:vm_target_hostname, "#{hostname}")
	prov.set_option(:host_name, "#{hostname}")
	$evm.log("info", "GetIP --> #{prov.inspect}")
end

##################################
# Find my environment            #
##################################
def find_environment(environment)
	case environment

		when "qa"
                $evm.log("info","qa")

			@gateway = "192.168.1.254"
			@network = "192.168.1.0/24"
			@dnsdomain = "acme.com"

		when "test"
                $evm.log("info","test")

			@gateway = "192.168.2.254"
			@network = "192.168.1.0/24"
			@dnsdomain = "acme.com"

		when "production"
                $evm.log("info","production")

			@gateway = "192.168.1.254"
			@network = "192.168.1.0/24"
			@dnsdomain = "acme.com"

        else
          $evm.log("info","NOTHING")

    end
end

#-----------------------MAIN PROGRAM-----------------------#


action = "getipnext"

username = "s50redhat"
password = "RedHat14"
server = "10.148.208.38"
@connection = "#{username}:#{password}@#{server}"
@staticIP = "192.168.1.22"


prov = $evm.root["miq_provision"]
# prov = $evm.root["vm"]
$evm.log("info","#{prov.inspect}")

# dialog_options = prov.miq_provision_request.options[:dialog]
#$evm.log("info","GetIP --> Dialog Options = #{dialog_options}")
			@gateway = "10.148.208.1"
			@network = "10.148.208.0/27"
			@dnsdomain = "plus.local"
#find_environment(dialog_options['dialog_environment'])

vm_target_name = prov.options[:vm_target_name]
# vm_target_name = prov.name

case action

  when "getipnext"
  
  	$evm.log("info", "netRef")	
  netRef = fetchRangeRef(@network)
  $evm.log("info", "netRef => #{netRef}")
  $evm.log("info", "nextIPADDR")
		nextIPADDR = nextIP(netRef)
  $evm.log("info", "nextIPADDR => #{nextIPADDR}")
    
		# macaddress = "00:50:56:%2$02x:%3$02x:%4$02x" % nextIPADDR.to_s.split('.')
		# macaddress = prov.mac_addresses[0]
  macaddress = prov.vm.mac_addresses[0]
		$evm.log("info", "macaddress --> #{macaddress}")
		result = getIP("#{vm_target_name}.#{@dnsdomain}", nextIPADDR, macaddress)
		if result ==  true
			$evm.log("info", "GetIP --> #{vm_target_name}.#{@dnsdomain} with IP Address #{nextIPADDR} created successfully")
			restartGrid()
	        netmask = netmask(@network)
			set_prov(prov, vm_target_name, nextIPADDR, netmask, @gateway, macaddress)
		elsif result == false
			$evm.log("info", "GetIP --> #{vm_target_name}.#{@dnsdomain} with IP Address #{nextIPADDR} FAILED")
		else
			$evm.log("info", "GetIP --> unknown error")
		end

  when "getipstatic"
		result = getIP("#{vm_target_name}.#{@dnsdomain}","#{@staticIP}")
		if result ==  true
                      $evm.log("info", "GetIP --> #{vm_target_name}.#{@dnsdomain} with IP Address #{@staticIP} created successfully")
                elsif result == false
                        $evm.log("info", "GetIP --> #{vm_target_name}.#{@dnsdomain} with IP Address #{@staticIP} FAILED")
                else
                        $evm.log("info", "GetIP --> unknown error")
                end

end

$evm.log("info", "********* InfoBlox - GetIP COMPLETED *********")
exit MIQ_OK

# Set Ruby rescue behaviour
rescue => err

  $evm.log(:error, "[#{err}]\n#{err.backtrace.join("\n")}")
  exit MIQ_ABORT

end
