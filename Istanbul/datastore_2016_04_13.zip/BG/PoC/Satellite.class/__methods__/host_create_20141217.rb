#
# Description: <Method description here>
#

begin

	# Method for logging
	def log(level, message)
		@method = '----- foreman host create -----'
		$evm.log(level, "#{@method} - #{message}")
	end

	# Method for adding new host to specified host group
	def set_hostgroup(vm, slot, host_id, instance_name, instance_port)

	uri_base = "https://#{@satellite_user}:#{@satellite_password}@#{@satellite_host}/api/v2"	
      uri = "#{uri_base}/hosts/#{host_id}/parameters"
		log(:info, "uri => #{uri}") if @debug

		headers = {'Content-Type' => 'application/json', 'Accept' => 'application/json;version=2'}

		request = RestClient::Request.new(
			method: :post,
			url: uri,
			headers: headers,
          payload: {:name => "instance#{slot}_name", :value => instance_name}.to_json
		)

	 	rest_return = request.execute
	 	log(:info, "rest_return => #{rest_return.inspect}")
      
 
 		request = RestClient::Request.new(
			method: :post,
			url: uri,
			headers: headers,
			payload: {:name => "instance#{slot}_port", :value => instance_port}.to_json
		)

	 	rest_return = request.execute
	 	log(:info, "rest_return => #{rest_return.inspect}")
      
      

      tag = slot + '_' + instance_name.downcase + '_' + instance_port
	 	log(:info, "tag => #{tag}") if @debug

		unless $evm.execute('tag_exists?', @category_name, tag)
			log(:info, "#{@method} - Creating <#{@category_name}/#{tag}> tag")
			$evm.execute('tag_create', @category_name, :name => tag, :description => tag)
		end
      
      vm.tag_assign("#{@category_name}/#{tag}")

	end

	# Start

	10.times { log(:info, 'CloudForms Automate Method Started') }
  10.times { log(:info, '============================================') }
	@debug = true

	require 'rest-client'
	require 'json'
	require 'openssl'

	@satellite_user = 'admin'
	@satellite_password = 'RedHat14'
	@satellite_host = 'satellite.plus.local'
	uri_base = "https://#{@satellite_user}:#{@satellite_password}@#{@satellite_host}/api/v2"

	prov = $evm.root['miq_provision']
	# prov = $evm.root['miq_provision'] || $evm.root['miq_provision_request'] || $evm.root['miq_provision_request_template']
	# log(:info, "prov.inspect => #{prov.inspect}")
	log(:info, "prov.vm.inspect => #{prov.vm.inspect}")

	vm = prov.vm unless prov.nil?
	raise 'The VM object is empty' if vm.nil?

	# Grab dialogue options
	options = prov.miq_provision_request.options[:dialog]
	$evm.log("info","Dialog Options = #{options}")
	raise 'The dialogue object is empty' if options.nil?
  
  	$evm.log("info","dialog_instance1_name => #{options["dialog_instance1_name"]}")
	$evm.log("info","dialog_instance1_port => #{options["dialog_instance1_port"]}")
  
#exit MIQ_OK
#

	# log(:info, "vm.inspect => #{vm.inspect}")

	# Create category

@category_name = 'db_slots'
#	unless $evm.execute('category_exists?', @category_name)
#		log(:info, "#{@method} - Category <#{@category_name}> doesn't exist, creating category")
#		$evm.execute('category_create', :name => @category_name, :single_value => single_value, :description => 'Database Slots')
#	end

  #############################
  # Create the host via Foreman
  #############################
  
 

  # Get_Hostgroup_id_by_Name
  headers = {"Content-Type" => 'application/json', "Accept" => 'application/json;version=2'}
  uri = "#{uri_base}/hostgroups?search=name=BGP_DB2"
  log(:info, "uri => #{uri}") if @debug

  body={}
  
  request = RestClient::Request.new(
    method: :get,
    url: uri,
    headers: headers
    )
  
  json=request.execute
  log(:info, "rest_return => #{json.inspect}")
  data=JSON.parse(json)
  results=data["results"][0]



 # Prepare host information  
   	hostinfo = {}

  	log(:info, 'Creating host')

	hostinfo[:name] = "#{vm.name}"
	# hostinfo[:name] = vm.name
	# hostinfo[:environment_id] = '4'
	hostinfo[:mac] = "#{vm.mac_addresses[0]}"
	# hostinfo[:mac] = vm.mac_addresses[0]
	hostinfo[:architecture_id] = '1'
	hostinfo[:operatingsystem_id] = '1'
	hostinfo[:location_id] = '2'
	hostinfo[:organization_id] = '1'
	hostinfo[:domain_id] = '1'
    hostinfo[:hostgroup_id] = (results["id"]).to_s
	hostinfo[:root_pass] = 'RedHat14'
	hostinfo[:ptable_id] = '7'
	hostinfo[:build] = 'true'

	body = { host: hostinfo }

	log(:info, "hostinfo => #{hostinfo}")

	headers = {'Content-Type' => 'application/json', 'Accept' => 'application/json;version=2'}
	uri = "#{uri_base}/hosts"
	log(:info, "uri => #{uri}") if @debug
    request = RestClient::Request.new(
		method: :post,
		url: uri,
		headers: headers,
		payload: body.to_json
	)

 	rest_return = request.execute
 	log(:info, "rest_return => #{rest_return.inspect}")

	#############################
	# Query via MAC to determine host id
	#############################

	log(:info, 'Querying host_id')

	headers = {"Content-Type" => 'application/json', "Accept" => 'application/json;version=2'}
	uri = "#{uri_base}/hosts?search=mac=#{vm.mac_addresses[0]}"

	body = {}

	log(:info, "uri => #{uri}") if @debug
	request = RestClient::Request.new(
		method: :get,
		url: uri,
		headers: headers
	)

	json=request.execute
	host_data=JSON.parse(json)
	results=host_data["results"][0]
	host_id=(results["id"]).to_s

	#############################
	# Set the host parameters
	#############################

	log(:info, 'Setting parameters')

	if options["dialog_instance1_name"].length > 0
		log(:info, "First instance => #{options["dialog_instance1_name"]}:#{options["dialog_instance1_port"]}")
		set_hostgroup(vm,"1",host_id,options["dialog_instance1_name"],options["dialog_instance1_port"])
	end
	if options["dialog_instance2_name"].length > 0
		log(:info, "Second instance => #{options["dialog_instance2_name"]}:#{options["dialog_instance2_port"]}")
		set_hostgroup(vm,"2",host_id,options["dialog_instance2_name"],options["dialog_instance2_port"])
	end
	if options["dialog_instance3_name"].length > 0
      log(:info, "Third instance => #{options["dialog_instance3_name"]}:#{options["dialog_instance3_port"]}")
		set_hostgroup(vm,"3",host_id,options["dialog_instance3_name"],options["dialog_instance3_port"])
	end
	if options["dialog_instance4_name"].length > 0
		log(:info, "Fourth instance => #{options["dialog_instance4_name"]}:#{options["dialog_instance4_port"]}")
		set_hostgroup(vm,"4",host_id,options["dialog_instance4_name"],options["dialog_instance4_port"])
	end

	log(:info, 'Stopping and restarting virtual machine')
	vm.stop
	sleep(3)
	vm.start

	10.times { log(:info, 'CloudForms Automate Method Ended') }
	exit MIQ_OK

rescue => err
	log(:error, "[#{err}]\n#{err.backtrace.join("\n")}")
	exit MIQ_ABORT

end
