#
# Description: validate_request (Service)
#

# Initialize Variables
prov = $evm.root['miq_request']
prov_resource = prov.resource
raise "Provisioning Request not found" if prov.nil? || prov_resource.nil?

# Initialize variables used
approval_req = false
reason5      = nil

###################################
#
# additional_approvers:
# Validate additional_approvers
#
###################################

description = "Approver #1"
$evm.root["miq_request"].add_approver(description)
reason5 = "Requested approval from:"
reason5 += " #{description}"


######################################
#
# Update Message to Requester
#
######################################
#if approval_req == true
  msg =  "Request was not auto-approved for the following reasons: "
  msg += "(#{reason5}) " unless reason5.nil?

  prov_resource.set_message(msg)
  $evm.log("info", "Inspecting Messge:<#{msg}>")

  $evm.root['ae_result'] = 'error'
  $evm.object['reason'] = msg
#end
